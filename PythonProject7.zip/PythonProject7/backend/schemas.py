# ==========================================================
# backend/schemas.py
# Defines data models for request validation and response structure
# ==========================================================

from pydantic import BaseModel
from typing import Optional, List


# ----------------------------------------------------------
# Input schema - what frontend sends to backend (/predict)
# ----------------------------------------------------------
class UserInput(BaseModel):
    name: str
    education: Optional[str] = ""
    skills: str
    interests: Optional[str] = ""


# ----------------------------------------------------------
# Output schema - what backend sends back to frontend
# ----------------------------------------------------------
class CareerOut(BaseModel):
    id: int
    career_name: str
    description: str
    required_skills: str
    score: float


# ----------------------------------------------------------
# Wrapper schema (optional) - useful if you want to structure API output
# ----------------------------------------------------------
class RecommendationResponse(BaseModel):
    recommendations: List[CareerOut]
