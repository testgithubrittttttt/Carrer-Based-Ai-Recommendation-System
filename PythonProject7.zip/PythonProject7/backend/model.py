# backend/model.py
from sentence_transformers import SentenceTransformer, util
import numpy as np
import joblib
from pathlib import Path
from database import get_connection
import re

ROOT = Path(__file__).resolve().parent
EMBEDDINGS_PATH = ROOT / "career_embeddings.joblib"
MODEL_NAME = "all-MiniLM-L6-v2"


def _tokenize_skills(text: str):
    """
    Convert a skills string into a normalized set of tokens.
    Handles comma-separated lists or space separated.
    """
    if not text:
        return set()
    # Replace common separators with comma, split, strip
    clean = re.sub(r"[;|\n/\\\t]+", ",", text.lower())
    parts = []
    for p in clean.split(","):
        p = p.strip()
        if p:
            # normalize multi-word skills (e.g., 'machine learning' -> 'machine learning')
            parts.append(p)
    return set(parts)


class CareerRecommender:
    def __init__(self, model_name=MODEL_NAME):
        print("🔄 Loading SentenceTransformer model...")
        self.model = SentenceTransformer(model_name)
        self.careers = []
        self.embeddings = None
        self._load_data()
        print("✅ Model and embeddings ready!")

    def _load_data(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, career_name, description, required_skills FROM careers")
        rows = cur.fetchall()
        conn.close()

        self.careers = [dict(r) for r in rows]
        if len(self.careers) == 0:
            raise ValueError("No career data found. Run seed_data.py first.")

        if EMBEDDINGS_PATH.exists():
            try:
                self.embeddings = joblib.load(EMBEDDINGS_PATH)
                if len(self.embeddings) != len(self.careers):
                    print("⚠️ Embedding length mismatch — recomputing embeddings.")
                    self._compute_and_save_embeddings()
            except Exception:
                print("⚠️ Failed to load cached embeddings — recomputing.")
                self._compute_and_save_embeddings()
        else:
            self._compute_and_save_embeddings()

    def _compute_and_save_embeddings(self):
        texts = [
            f"{c['career_name']} {c['required_skills']} {c['description']}"
            for c in self.careers
        ]
        print("🧠 Computing career embeddings (this may take a moment)...")
        self.embeddings = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=True)
        joblib.dump(self.embeddings, EMBEDDINGS_PATH)
        print("💾 Embeddings saved to:", EMBEDDINGS_PATH)

    def recommend(self, user_text: str, top_k: int = 3):
        if self.embeddings is None:
            raise RuntimeError("Embeddings not loaded.")

        # Compute user embedding
        user_emb = self.model.encode([user_text], convert_to_numpy=True)[0]
        scores = util.cos_sim(user_emb, self.embeddings).numpy()[0]
        top_indices = np.argsort(scores)[-top_k:][::-1]

        # For explainability: try to find exact skill token overlap
        # Normalize user skills by splitting on commas and punctuation
        user_skill_set = _tokenize_skills(user_text)

        recommendations = []
        for idx in top_indices:
            c = self.careers[idx].copy()
            score_val = float(scores[idx])
            c["score"] = score_val

            # matched_skills: intersection of tokenized sets
            career_skill_set = _tokenize_skills(c.get("required_skills", ""))
            overlap = user_skill_set.intersection(career_skill_set)
            if overlap:
                c["matched_skills"] = ", ".join(sorted(overlap))
            else:
                c["matched_skills"] = "No direct token overlap — semantic match"

            recommendations.append(c)

        return recommendations


# Singleton pattern to avoid reloading model multiple times
_recommender = None


def get_recommender():
    global _recommender
    if _recommender is None:
        _recommender = CareerRecommender()
    return _recommender


if __name__ == "__main__":
    rec = get_recommender()
    test_text = "python, data analysis, machine learning"
    top = rec.recommend(test_text, top_k=3)
    print("Top recommendations for:", test_text)
    for r in top:
        print(r["career_name"], r["score"], "matched:", r["matched_skills"])
