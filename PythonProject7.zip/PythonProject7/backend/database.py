import sqlite3
from pathlib import Path

# Path to your database file
DB_PATH = Path(__file__).resolve().parent.parent / "database" / "careers.db"

# Ensure the database folder exists
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# SQL table creation queries
CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    education TEXT,
    skills TEXT,
    interests TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

CREATE_CAREERS = """
CREATE TABLE IF NOT EXISTS careers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    career_name TEXT,
    description TEXT,
    required_skills TEXT
);
"""

CREATE_RECOMMENDATIONS = """
CREATE TABLE IF NOT EXISTS recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    career_id INTEGER,
    score REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


def get_connection():
    """Create and return a SQLite connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Allows dict-like row access
    return conn


def init_db():
    """Initialize database and create tables if they don’t exist."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(CREATE_USERS)
    cur.execute(CREATE_CAREERS)
    cur.execute(CREATE_RECOMMENDATIONS)
    conn.commit()
    conn.close()


# Run directly to initialize the DB (optional)
if __name__ == "__main__":
    init_db()
    print(f"✅ Database initialized successfully at: {DB_PATH}")
