# backend/main.py
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from schemas import UserInput
from model import get_recommender
from database import get_connection, init_db
from resume_parser import parse_resume
import tempfile
import os

app = FastAPI(title="Career Recommendation System API", version="1.1")

# CORS for local Streamlit (allow all for dev)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize DB and model
init_db()
recommender = get_recommender()


@app.get("/")
def root():
    return {"message": "🎯 Career Recommendation System API is running successfully!"}


@app.post("/predict")
def predict(user: UserInput):
    """
    Accepts user data and returns top 3 career recommendations.
    """
    user_text = f"{user.skills} {user.interests} {user.education}".strip()
    if not user_text:
        raise HTTPException(status_code=400, detail="Please provide skills or interests for recommendation.")

    # Get recommendations (model returns list of dicts with explainability fields)
    try:
        recommendations = recommender.recommend(user_text, top_k=5)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Model error: {e}")

    # Store user and top-3 recommendations in DB
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO users (name, education, skills, interests) VALUES (?, ?, ?, ?)",
        (user.name, user.education, user.skills, user.interests)
    )
    user_id = cur.lastrowid

    for rec in recommendations[:3]:
        cur.execute(
            "INSERT INTO recommendations (user_id, career_id, score) VALUES (?, ?, ?)",
            (user_id, rec['id'], rec['score'])
        )
    conn.commit()
    conn.close()

    # Prepare output
    top_recs = [
        {
            "id": rec["id"],
            "career_name": rec["career_name"],
            "description": rec["description"],
            "required_skills": rec["required_skills"],
            "score": round(rec["score"], 4),
            "matched_skills": rec.get("matched_skills", "")
        }
        for rec in recommendations[:3]
    ]

    return {"recommendations": top_recs}


@app.get("/careers")
def get_all_careers():
    """Return all careers in DB."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, career_name, description, required_skills FROM careers")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.post("/parse_resume")
def parse_resume_api(file: UploadFile = File(...)):
    """
    Accept uploaded PDF resume and return extracted skills, education, interests.
    """
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF resumes are supported.")

    try:
        # write to a temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(file.file.read())
            tmp_path = tmp.name

        result = parse_resume(tmp_path)

        # cleanup temp file
        try:
            os.remove(tmp_path)
        except Exception:
            pass

        return {"message": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Resume parsing error: {e}")
