# backend/seed_data.py
import pandas as pd
import sqlite3
from pathlib import Path

# Define paths
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR.parent / "database" / "careers.db"
CSV_PATH = BASE_DIR / "careers_seed.csv"

print("🔍 CSV Path:", CSV_PATH)
print("🔍 Database Path:", DB_PATH)

# Create database directory if not exists
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

# Read the CSV safely
try:
    df = pd.read_csv(
        CSV_PATH,
        encoding="utf-8",
        engine="python",          # handles complex CSVs
        quotechar='"',            # handles commas inside text
        skipinitialspace=True     # ignores spaces after commas
    )
except Exception as e:
    print("❌ Error reading CSV file:", e)
    exit(1)

# Connect to SQLite
conn = sqlite3.connect(DB_PATH)

# Create careers table if not exists
conn.execute("""
CREATE TABLE IF NOT EXISTS careers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    career_name TEXT,
    description TEXT,
    required_skills TEXT,
    domain TEXT,
    average_salary TEXT,
    education_path TEXT
)
""")

# Clear existing records (optional)
conn.execute("DELETE FROM careers")

# Insert records from CSV
insert_query = """
INSERT INTO careers (
    career_name,
    description,
    required_skills,
    domain,
    average_salary,
    education_path
) VALUES (?, ?, ?, ?, ?, ?)
"""

for _, row in df.iterrows():
    try:
        conn.execute(insert_query, (
            str(row.get("career_name", "")),
            str(row.get("description", "")),
            str(row.get("required_skills", "")),
            str(row.get("domain", "")),
            str(row.get("average_salary", "")),
            str(row.get("education_path", ""))
        ))
    except Exception as e:
        print(f"⚠️ Skipped a row due to error: {e}")

conn.commit()
conn.close()

print(f"✅ Successfully seeded {len(df)} careers into the database!")
