# backend/resume_parser.py
import fitz  # PyMuPDF
import re
import spacy
from pathlib import Path

# Load SpaCy model once
try:
    nlp = spacy.load("en_core_web_sm")
except Exception:
    # if model not available, raise clear error for user to install
    raise RuntimeError("SpaCy model 'en_core_web_sm' not found. Run: python -m spacy download en_core_web_sm")

# Minimal skill dictionary - expand as needed
SKILL_KEYWORDS = [
    "python", "java", "c++", "machine learning", "deep learning", "nlp",
    "sql", "tableau", "excel", "pandas", "numpy", "power bi", "html",
    "css", "javascript", "react", "flask", "fastapi", "docker", "aws",
    "kubernetes", "git", "tensorflow", "pytorch", "scikit-learn"
]


def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract text from PDF file using PyMuPDF."""
    text = ""
    doc = fitz.open(pdf_path)
    for page in doc:
        text += page.get_text("text")
    return text


def extract_skills(text: str):
    """Find keywords from SKILL_KEYWORDS in the resume text."""
    text_lower = text.lower()
    found = [s for s in SKILL_KEYWORDS if s in text_lower]
    # return unique sorted skills
    return sorted(set(found))


def extract_education(text: str):
    """Simple regex-based extraction of education terms."""
    patterns = [
        r"\b(B\.?Tech|BTech|Bachelor of Technology|Bachelor of Engineering|B\.?E\.?)\b",
        r"\b(M\.?Tech|MTech|Master of Technology|M\.?S|MS|MSc|Master)\b",
        r"\b(B\.?Sc|BSc|Bachelor)\b",
        r"\b(MBA|MBA)\b",
        r"\b(Ph\.?D|PhD)\b",
        r"\b(Computer Science|Information Technology|Electronics|Mechanical)\b"
    ]
    found = set()
    for p in patterns:
        for m in re.findall(p, text, flags=re.IGNORECASE):
            found.add(m if isinstance(m, str) else "".join(m))
    return ", ".join(found) if found else ""


def infer_interests(text: str, top_n: int = 8):
    """A naive interest extractor: top frequent nouns / keywords from NLP."""
    doc = nlp(text)
    nouns = [token.lemma_.lower() for token in doc if token.pos_ in ("NOUN", "PROPN") and len(token.lemma_) > 3]
    freq = {}
    for n in nouns:
        freq[n] = freq.get(n, 0) + 1
    sorted_nouns = sorted(freq.items(), key=lambda x: x[1], reverse=True)
    return ", ".join([n for n, _ in sorted_nouns[:top_n]])


def parse_resume(file_path: str):
    """
    Extracts skills, education, and interests from a resume PDF and returns a dict.
    """
    text = extract_text_from_pdf(file_path)
    if not text.strip():
        return {"skills": "", "education": "", "interests": ""}

    skills = extract_skills(text)
    education = extract_education(text)
    interests = infer_interests(text)

    return {
        "skills": ", ".join(skills) if skills else "",
        "education": education if education else "",
        "interests": interests if interests else ""
    }
