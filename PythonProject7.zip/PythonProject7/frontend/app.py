# frontend/app.py
import streamlit as st
import requests
import pandas as pd
from pathlib import Path

API_URL = "http://127.0.0.1:8000"

st.set_page_config(page_title="AI Career Recommender", page_icon="🎯", layout="centered")

# --- Styling (kept lightweight) ---
st.markdown("""
    <style>
        .title { text-align: center; font-size: 32px; font-weight: 700; }
        .subtitle { text-align: center; color: #555; margin-bottom: 18px; }
        .card { background-color: white; padding: 16px; border-radius: 12px; box-shadow: 0 6px 18px rgba(0,0,0,0.06); }
    </style>
""", unsafe_allow_html=True)

st.markdown("<div class='title'>🎯 AI Career Recommendation System</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Upload resume or enter skills to get AI-powered career recommendations</div>", unsafe_allow_html=True)
st.markdown("---")

# Initialize session state keys for autofill
if "skills" not in st.session_state:
    st.session_state["skills"] = ""
if "education" not in st.session_state:
    st.session_state["education"] = ""
if "interests" not in st.session_state:
    st.session_state["interests"] = ""

# Resume upload block (above the form)
st.subheader("📄 Upload Resume (optional)")
uploaded_resume = st.file_uploader("Upload your resume (PDF)", type=["pdf"])
if uploaded_resume is not None:
    with st.spinner("🧠 Parsing resume..."):
        try:
            files = {"file": (uploaded_resume.name, uploaded_resume.getvalue(), "application/pdf")}
            resp = requests.post(f"{API_URL}/parse_resume", files=files, timeout=60)
            if resp.status_code == 200:
                data = resp.json().get("data", {})
                st.success("✅ Resume parsed successfully — fields auto-filled below.")
                # Autofill session state
                st.session_state["skills"] = data.get("skills", "")
                st.session_state["education"] = data.get("education", "")
                st.session_state["interests"] = data.get("interests", "")
            else:
                st.error("❌ Failed to parse resume. Backend returned error.")
        except requests.exceptions.RequestException:
            st.error("❌ Could not connect to backend to parse resume.")

st.markdown("---")

# Input form
with st.form("career_form"):
    st.subheader("🧠 Tell us about yourself")
    name = st.text_input("👤 Your Name", placeholder="e.g. Dhruv Sharma")
    education = st.text_input("🎓 Education", value=st.session_state.get("education", ""), placeholder="e.g. B.Tech in Computer Science")
    skills = st.text_area("💼 Skills (comma separated)", value=st.session_state.get("skills", ""), placeholder="e.g. python, sql, machine learning")
    interests = st.text_area("✨ Interests (optional)", value=st.session_state.get("interests", ""))

    submitted = st.form_submit_button("🚀 Get Recommendations")

if submitted:
    if not skills.strip():
        st.error("Please enter some skills or upload a resume.")
    else:
        payload = {
            "name": name or "Anonymous",
            "education": education,
            "skills": skills,
            "interests": interests
        }
        with st.spinner("🤖 Finding best careers for you..."):
            try:
                resp = requests.post(f"{API_URL}/predict", json=payload, timeout=40)
                if resp.status_code == 200:
                    recs = resp.json().get("recommendations", [])
                    if not recs:
                        st.info("No recommendations returned.")
                    else:
                        st.markdown("---")
                        st.subheader("🎓 Top Career Recommendations")
                        for i, r in enumerate(recs, start=1):
                            with st.expander(f"🔹 {i}. {r['career_name']} (Score: {r['score']:.2f})"):
                                st.markdown(f"**🧾 Description:** {r['description']}")
                                st.markdown(f"**🧠 Required Skills:** {r['required_skills']}")
                                st.markdown(f"**✅ Matched Skills:** {r.get('matched_skills', 'N/A')}")
                        st.balloons()
                else:
                    st.error(f"Backend error: {resp.status_code} — {resp.text}")
            except requests.exceptions.RequestException:
                st.error("Could not connect to backend. Is the API running at http://127.0.0.1:8000 ?")

# Optional: show careers DB table
st.markdown("---")
with st.expander("📚 View All Careers in Dataset"):
    try:
        resp = requests.get(f"{API_URL}/careers", timeout=10)
        if resp.status_code == 200:
            df = pd.DataFrame(resp.json())
            if not df.empty:
                st.dataframe(df[["career_name", "description", "required_skills"]])
            else:
                st.info("Career dataset is empty. Run seed_data.py to populate.")
        else:
            st.warning("Could not fetch careers from backend.")
    except Exception:
        st.warning("Could not connect to backend to fetch careers.")
