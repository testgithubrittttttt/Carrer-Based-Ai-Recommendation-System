# ==========================================================
# frontend/utils.py
# Handles API communication with FastAPI backend
# ==========================================================

import requests

# URL of your FastAPI backend (update port if needed)
API_URL = "http://127.0.0.1:8000"


def get_recommendations(payload: dict):
    """
    Send user data to FastAPI backend and get recommendations.
    """
    try:
        response = requests.post(f"{API_URL}/predict", json=payload, timeout=40)
        if response.status_code == 200:
            return response.json().get("recommendations", [])
        else:
            print(f"⚠️ Backend returned error {response.status_code}: {response.text}")
            return None
    except requests.exceptions.ConnectionError:
        print("❌ Connection error — backend might not be running.")
        return None
    except Exception as e:
        print(f"⚠️ Unexpected error: {e}")
        return None


def get_all_careers():
    """
    Fetch all careers from backend (for optional display).
    """
    try:
        response = requests.get(f"{API_URL}/careers", timeout=15)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"⚠️ Backend returned error {response.status_code}")
            return []
    except Exception:
        print("⚠️ Could not connect to backend.")
        return []
